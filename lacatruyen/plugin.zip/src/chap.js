var BUILD_ID = "OXnIhVnz4Av-xhJvUKz7a";

function execute(url) {

  var parts = url.split("/");
  var slug = parts[parts.length - 2];
  var chapterSlug = parts[parts.length - 1];

  var api = "https://lacatruyen.com/_next/data/" +
            BUILD_ID +
            "/story/" +
            slug + "/" +
            chapterSlug +
            ".json?slug=" +
            slug +
            "&chapter=" +
            chapterSlug;

  var res = fetch(api);

  if (!res.ok) {
    return Response.error("Chapter API failed: " + res.status);
  }

  var json = res.json();

  var chapter = json.pageProps.chapter;

  return Response.success({
    name: chapter.title,
    content: chapter.content
  });
}