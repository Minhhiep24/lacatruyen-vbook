var BUILD_ID = "OXnIhVnz4Av-xhJvUKz7a";

function execute(url) {

  var slug = url.split("/").pop();

  var api = "https://lacatruyen.com/_next/data/" +
            BUILD_ID +
            "/story/" +
            slug +
            ".json?slug=" +
            slug;

  var res = fetch(api);

  if (!res.ok) {
    return Response.error("Toc API failed: " + res.status);
  }

  var json = res.json();

  var chapters = json.pageProps.firstChapter;

  var list = [];

  chapters.forEach(function(ch) {
    list.push({
      name: ch.title,
      link: "https://lacatruyen.com/truyen/" +
            slug + "/" + ch.slug,
      host: "https://lacatruyen.com"
    });
  });

  return Response.success(list);
}