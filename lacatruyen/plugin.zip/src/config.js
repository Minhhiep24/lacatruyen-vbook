function getHost() {
    return "https://lacatruyen.com";
}

function getHeaders() {
    return {
        "content-type": "application/json",
        "origin": "https://lacatruyen.com",
        "referer": "https://lacatruyen.com/",
        "user-agent": "Mozilla/5.0"
    };
}