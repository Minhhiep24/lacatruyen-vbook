var BUILD_ID = "OXnIhVnz4Av-xhJvUKz7a";

function execute(url) {

  var slug = url.split("/").pop();

  var api = "https://lacatruyen.com/_next/data/" +
            BUILD_ID +
            "/story/" +
            slug +
            ".json?slug=" +
            slug;

  var res = fetch(api);

  if (!res.ok) {
    return Response.error("Detail API failed: " + res.status);
  }

  var json = res.json();

  var story = json.pageProps.story;

  return Response.success({
    name: story.title,
    cover: "https://lacatruyen.com/storage/" + story.image,
    author: story.pen_name_user || "",
    description: story.description || "",
    detail: story.detail || ""
  });
}